//
//  TAPOWENCRYPTION.h
//  TAPOWENCRYPTION
//
//  Created by Singsys on 3/12/18.
//  Copyright © 2018 Singsys. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TAPOWENCRYPTION.
FOUNDATION_EXPORT double TAPOWENCRYPTIONVersionNumber;

//! Project version string for TAPOWENCRYPTION.
FOUNDATION_EXPORT const unsigned char TAPOWENCRYPTIONVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TAPOWENCRYPTION/PublicHeader.h>


